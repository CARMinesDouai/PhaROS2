#include <pharosmsgs/pharosmsgs.h>

struct geometry_msgs__msg__Twist * setDataToTwist(float lx, float ly, float lz, float ax, float ay, float az) {
  struct geometry_msgs__msg__Twist * msg = malloc(sizeof(struct geometry_msgs__msg__Twist));

  msg->linear.x=lx;
  msg->linear.y=ly;
  msg->linear.z=lz;
  
  msg->angular.x=ax;
  msg->angular.y=ay;
  msg->angular.z=az;
  
  return msg;
}

float getAxes(sensor_msgs__msg__Joy * msg, int at) {
  return msg->axes.data[at];
}

float getButton(sensor_msgs__msg__Joy * msg, int at) {
  return msg->buttons.data[at];
}
