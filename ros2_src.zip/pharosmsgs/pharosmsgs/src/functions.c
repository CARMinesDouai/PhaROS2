#include <pharosmsgs/pharosmsgs.h>

rclc_message_type_support_t get_geometry_msgs_Vector3() { return RCLC_GET_MSG_TYPE_SUPPORT(geometry_msgs,msg,Vector3);}
rclc_message_type_support_t get_geometry_msgs_Twist() { return RCLC_GET_MSG_TYPE_SUPPORT(geometry_msgs,msg,Twist);}
rclc_message_type_support_t get_builtin_interfaces_Time() { return RCLC_GET_MSG_TYPE_SUPPORT(builtin_interfaces,msg,Time);}
rclc_message_type_support_t get_std_msgs_Header() { return RCLC_GET_MSG_TYPE_SUPPORT(std_msgs,msg,Header);}
rclc_message_type_support_t get_sensor_msgs_Joy() { return RCLC_GET_MSG_TYPE_SUPPORT(sensor_msgs,msg,Joy);}
rclc_message_type_support_t get_std_msgs_Float32() { return RCLC_GET_MSG_TYPE_SUPPORT(std_msgs,msg,Float32);}
rclc_message_type_support_t get_std_msgs_Float64() { return RCLC_GET_MSG_TYPE_SUPPORT(std_msgs,msg,Float64);}
rclc_message_type_support_t get_std_msgs_String() { return RCLC_GET_MSG_TYPE_SUPPORT(std_msgs,msg,String);}
