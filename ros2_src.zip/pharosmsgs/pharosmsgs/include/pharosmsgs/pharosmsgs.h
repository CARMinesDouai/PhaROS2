#ifndef PHAROSMSGS__PHAROSMSGS_H_
#define PHAROSMSGS__PHAROSMSGS_H_

#if __cplusplus
extern "C"
{
#endif

#include <stdbool.h>  // For bool
#include <stddef.h>  // For size_t

#include "rosidl_generator_c/message_type_support_struct.h"
#include "rclc/types.h"  // For rclc_*_t types
#include "rclc/rclc.h"

#include "pharosmsgs/includes.h"


#include "pharosmsgs/signatures.h"



#include "geometry_msgs/msg/twist.h"
#include "sensor_msgs/msg/joy.h"


struct std_msgs__msg__String * setDataToStringTypeSupport(char * data);
struct geometry_msgs__msg__Twist * setDataToTwist(float lx, float ly, float lz, float ax, float ay, float az);
float getAxes(sensor_msgs__msg__Joy * msg, int at);
float getButton(sensor_msgs__msg__Joy * msg, int at);

#if __cplusplus
}
#endif

#endif  // RCLC__RCLC_H_
